library(testthat)
library(spectratrait)

test_check("spectratrait")