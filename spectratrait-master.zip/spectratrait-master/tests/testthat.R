library(testthat)
test_check("spectratrait")